﻿@[TOC]( 任务清单（纯HTML）- 交互式任务管理工具)
# 功能展示

本清单应用将会议筹备流程与现代Web技术完美结合，通过精心设计的交互体验和实用功能，帮助会议组织者高效完成筹备工作，确保每个环节都不遗漏！

![在这里插入图片描述](https://i-blog.csdnimg.cn/direct/2b1f65cccb694603afd3419e330b9079.png#pic_center)

 ## 1.任务管理
 **交互式任务清单**
清晰展示5项会议筹备核心任务
**智能勾选系统**
点击复选框或任务文字均可标记完成
**视觉反馈**
已完成任务显示删除线
已完成任务栏变为浅绿色背景，与未完成任务形成明显色差对比
任务栏添加1px边框，清晰区分每条任务
移除左侧蓝色小条，界面更简洁

 ## 2.进度统计
 实时显示"已完成X/Y项"的统计信息
统计区域有特殊背景和边框，突出显示
数据随任务状态实时更新
## 3.本地存储
使用[localStorage](https://so.csdn.net/so/search?spm=1000.2115.3001.4498&q=localStorage&t=&u=)自动保存任务完成状态
刷新页面后状态保持不变
夜间模式偏好也会被记忆保存

## 4. 主题与显示
**双模式切换**
日间模式：明亮清晰，适合白天使用
夜间模式：
一键切换，按钮文字智能变化（"🌙 夜间模式" ↔ "☀️ 日间模式"）
全界面深色适配（背景、文字、任务栏、复选框等）
保护视力，适合夜间工作
**视觉设计**
柔和渐变色背景，不干扰内容阅读
轻盈质感，提升视觉体验
交互优化：
悬停效果：按钮和任务项有微妙动画反馈
自定义复选框：绿色背景+白色对勾，更直观醒目
任务栏悬停高亮，提升可操作性

## 5.分享与导出
**二维码分享**
点击"生成二维码"弹出当前页面访问链接
专为手机扫描优化的200×200大小
防止重复生成，确保性能
手机扫码后可继续操作，状态同步
**文档处理**
一键导出PDF：
保持原有样式和格式
专业A4排版
适合存档或分享
**打印功能**
专为打印设计的页面样式
一键调用浏览器打印功能
去除背景色，节省墨水
## 6.操作效率
**批量操作**
全选/取消全选：
智能判断当前状态（全选时显示"取消全选"）
一键完成所有任务状态切换
状态自动保存
**移动友好**
响应式设计，适配各种设备
触摸区域优化，手机操作无障碍
二维码分享实现跨设备同步
## 7.技术特性
**纯前端实现**
单HTML文件即可运行，无需服务器
仅依赖两个外部CDN库（可离线使用核心功能）
轻量级，加载迅速
**数据安全**
所有数据保存在本地浏览器
无数据上传，保护隐私
可完全离线使用（除PDF导出外）
**便捷部署**
双击即可运行，无需安装
支持本地服务器部署
兼容GitHub Pages等静态网站托管
**自定义能力**
任务列表可通过修改JS数组轻松调整
支持增删任务项
适配不同会议类型需求
**样式调整**
CSS模块化设计，易于修改主题色
布局参数清晰，可调整间距、圆角等
支持自定义背景和字体
# 界面预览
主界面 - 日间模式
![主界面 - 日间模式](https://i-blog.csdnimg.cn/direct/c31c4ebfea2e4387bfa71acd2f37586c.png#pic_center)
夜间模式 & 已完成任务效果
![夜间模式 & 已完成任务效果](https://i-blog.csdnimg.cn/direct/70dd8ce50e764ad388212f4ecc049d35.png#pic_center)
二维码分享功能
![二维码分享功能](https://i-blog.csdnimg.cn/direct/fae6e8880b8e4cbca6865caddc5af451.png#pic_center)

# 完整代码

```html
<!DOCTYPE html>
<html lang="zh">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>筹备会议行动清单</title>

  <!-- ✅ 正确的 html2pdf.js CDN（用于导出 PDF） -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

  <!-- ✅ 正确的 QRCode.js CDN（关键修复） -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>

  <style id="pageStyle">
    /* ===== 动态波浪背景 ===== */
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      min-height: 100vh;
      background: linear-gradient(45deg, #f0f7ff, #e6f3f9);
      background-attachment: fixed;
      position: relative;
      overflow: hidden;
    }

    body::before {
      content: '';
      position: fixed;
      top: 0; left: 0; right: 0; bottom: 0;
      background-image: url("image/svg+xml,%3Csvg width='42' height='42' viewBox='0 0 42 42' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%235dade2' fill-opacity='0.05'%3E%3Cpath d='M21 0c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zm0 26c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zm0 13c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zm0-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm0-26c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm0 26c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5z'%2F%3E%3C/g%3E%3C/svg%3E");
      background-size: 42px 42px;
      animation: pan 20s linear infinite;
      z-index: -1;
      opacity: 0.6;
    }

    @keyframes pan {
      0% { transform: translate(0, 0); }
      100% { transform: translate(42px, 42px); }
    }

    .container {
      max-width: 1000px;
      margin: 30px auto;
      padding: 30px;
      background-color: #ffffff;
      border-radius: 12px;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
    }

    h1 {
      text-align: center;
      color: #2c3e50;
      font-size: 32px;
      margin-bottom: 16px;
      font-weight: 600;
    }

    .controls {
      display: flex;
      justify-content: center;
      gap: 16px;
      margin: 24px 0;
      flex-wrap: wrap;
    }

    button {
      padding: 12px 24px;
      font-size: 16px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.2s ease;
      font-weight: 500;
    }

    .btn-select { background-color: #3498db; color: white; }
    .btn-print { background-color: #2ecc71; color: white; }
    .btn-export { background-color: #9b59b6; color: white; }
    .btn-qrcode { background-color: #f39c12; color: white; }
    .btn-theme { background-color: #7f8c8d; color: white; }

    button:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
    }

    ul {
      list-style: none;
      padding: 0;
    }

    li {
      padding: 18px 24px;
      margin: 14px 0;
      border-radius: 8px;
      border: 1px solid #dde4e9;
      display: flex;
      align-items: flex-start;
      transition: all 0.3s ease;
      cursor: pointer;
      background-color: #fdfefe;
    }

    li:hover {
      border-color: #a0d2f0;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
    }

    li.completed {
      background-color: #e8f8f1;
      border-color: #b8e6d9;
      color: #777;
    }

    li.completed span.task-text {
      text-decoration: line-through;
      color: #888;
    }

    .task-checkbox {
      position: absolute;
      opacity: 0;
      cursor: pointer;
    }

    .checkmark {
      display: inline-flex;
      width: 22px;
      height: 22px;
      background-color: #eee;
      border: 2px solid #ccc;
      border-radius: 6px;
      margin-right: 14px;
      flex-shrink: 0;
      justify-content: center;
      align-items: center;
      color: white;
      font-weight: bold;
      margin-top: 5px;
    }

    .task-checkbox:checked + .checkmark {
      background-color: #2ecc71;
      border-color: #27ae60;
    }

    .task-checkbox:checked + .checkmark::after {
      content: '✓';
      display: block;
      color: white;
      font-size: 18px;
    }

    .task-checkbox + .checkmark::after {
      content: '';
    }

    .task-text {
      font-size: 18px;
      flex: 1;
      cursor: pointer;
      user-select: none;
    }

    .summary {
      text-align: center;
      margin-top: 30px;
      font-size: 20px;
      font-weight: bold;
      color: #2c3e50;
      padding: 16px;
      background-color: #f5f9fc;
      border-radius: 8px;
      border: 1px solid #d0e7f4;
    }

    /* ============ 夜间模式样式 ============ */
    body.night {
      background: #121212;
      color: #e0e0e0;
    }

    body.night::before {
      opacity: 0.2;
    }

    body.night .container {
      background-color: #1e1e1e;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.4);
    }

    body.night h1,
    body.night .summary,
    body.night li {
      color: #e0e0e0;
    }

    body.night li {
      background-color: #2a2a2a;
      border-color: #444;
    }

    body.night li.completed {
      background-color: #1a362c;
      border-color: #2c5c49;
    }

    body.night .summary {
      background-color: #2d2d2d;
      border-color: #444;
    }

    body.night .checkmark {
      background-color: #333;
      border-color: #555;
    }

    body.night .task-checkbox:checked + .checkmark {
      background-color: #27ae60;
    }
  </style>
</head>
<body>

  <!-- 二维码弹窗 -->
  <div id="qrcodeModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 1000; justify-content: center; align-items: center;">
    <div style="background: white; padding: 20px; border-radius: 12px; text-align: center;">
      <h3>📱 扫码在手机查看</h3>
      <div id="qrcode"></div>
      <button onclick="closeQrCode()" style="margin-top: 15px; padding: 8px 16px; background: #333; color: white; border: none; border-radius: 6px; cursor: pointer;">关闭</button>
    </div>
  </div>

  <div class="container" id="exportArea">
    <h1>筹备会议行动清单</h1>

    <div class="controls">
      <button id="toggleAll">🔄 全选 / 取消全选</button>
      <button onclick="window.print()">🖨️ 打印清单</button>
      <button id="exportPdf">📥 导出为 PDF</button>
      <button id="showQrCode" class="btn-qrcode">📱 生成二维码</button>
      <button id="themeToggle" class="btn-theme">🌙 夜间模式</button>
    </div>

    <ul id="taskList">
      <!-- 任务由 JS 生成 -->
    </ul>

    <div class="summary" id="summary">
      已完成 0 / 5 项
    </div>
  </div>

  <script>
    const tasks = [
      "准备会前播放视频。",
      "按照中心统一格式模版制作、打印会议议程（参会领导、参会人员、工作人员每人1份）、签到表（1份），发放到位。",
      "打印参会人员通讯录2份。",
      "连接会议须用电脑、音频设备进行PPT、音频试放。",
      "准备话筒若干；会前30分钟播放中心视频，按照会议议程安排播放PPT、音频。"
    ];

    const taskList = document.getElementById('taskList');
    const summary = document.getElementById('summary');
    const toggleAllBtn = document.getElementById('toggleAll');
    const exportPdfBtn = document.getElementById('exportPdf');
    const showQrCodeBtn = document.getElementById('showQrCode');
    const themeToggleBtn = document.getElementById('themeToggle');
    const qrcodeModal = document.getElementById('qrcodeModal');

    let completedStatus = JSON.parse(localStorage.getItem('taskCompleted')) || tasks.map(() => false);

    function updateSummary() {
      const completed = completedStatus.filter(status => status).length;
      summary.textContent = `已完成 ${completed} / ${tasks.length} 项`;
    }

    tasks.forEach((task, index) => {
      const li = document.createElement('li');
      if (completedStatus[index]) li.classList.add('completed');
      li.setAttribute('data-index', index);

      const label = document.createElement('label');
      label.style = 'display: flex; align-items: flex-start; width: 100%;';

      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.className = 'task-checkbox';
      checkbox.checked = completedStatus[index];

      const checkmark = document.createElement('span');
      checkmark.className = 'checkmark';

      const span = document.createElement('span');
      span.className = 'task-text';
      span.textContent = task;

      label.appendChild(checkbox);
      label.appendChild(checkmark);
      label.appendChild(span);
      li.appendChild(label);
      taskList.appendChild(li);

      li.addEventListener('click', function (e) {
        const target = e.target;
        if (target === checkbox || target === checkmark || target === span) {
          const idx = parseInt(li.getAttribute('data-index'));
          const isChecked = checkbox.checked;

          checkbox.checked = !isChecked;
          completedStatus[idx] = !isChecked;
          li.classList.toggle('completed', !isChecked);
          localStorage.setItem('taskCompleted', JSON.stringify(completedStatus));
          updateSummary();
        }
      });

      checkbox.addEventListener('change', function () {
        const idx = parseInt(li.getAttribute('data-index'));
        completedStatus[idx] = this.checked;
        li.classList.toggle('completed', this.checked);
        localStorage.setItem('taskCompleted', JSON.stringify(completedStatus));
        updateSummary();
      });
    });

    // 全选 / 取消全选
    toggleAllBtn.addEventListener('click', () => {
      const isAllCompleted = completedStatus.every(status => status);
      const newStatus = !isAllCompleted;
      completedStatus = tasks.map(() => newStatus);

      document.querySelectorAll('#taskList li').forEach((li, index) => {
        const checkbox = li.querySelector('.task-checkbox');
        checkbox.checked = newStatus;
        li.classList.toggle('completed', newStatus);
      });

      localStorage.setItem('taskCompleted', JSON.stringify(completedStatus));
      updateSummary();
    });

    // 导出为 PDF
    exportPdfBtn.addEventListener('click', () => {
      const opt = {
        margin: 10,
        filename: '会议筹备清单.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
      };
      html2pdf().from(document.getElementById('exportArea')).set(opt).save();
    });

    // 生成二维码（✅ 修复：只生成一次）
    showQrCodeBtn.addEventListener('click', () => {
      qrcodeModal.style.display = 'flex';
      const qrcodeDiv = document.getElementById('qrcode');

      // 防止重复生成
      if (qrcodeDiv.querySelector('canvas') === null && qrcodeDiv.querySelector('img') === null) {
        const currentUrl = window.location.href;
        new QRCode(qrcodeDiv, {
          text: currentUrl,
          width: 200,
          height: 200,
          colorDark: "#000",
          colorLight: "#fff"
        });
      }
    });

    function closeQrCode() {
      qrcodeModal.style.display = 'none';
    }

    // 夜间模式切换
    themeToggleBtn.addEventListener('click', () => {
      const isNight = document.body.classList.toggle('night');
      themeToggleBtn.textContent = isNight ? '☀️ 日间模式' : '🌙 夜间模式';
      localStorage.setItem('nightMode', isNight);
    });

    // 恢复夜间模式
    if (localStorage.getItem('nightMode') === 'true') {
      document.body.classList.add('night');
      themeToggleBtn.textContent = '☀️ 日间模式';
    }

    updateSummary();
  </script>

</body>
</html>
```
也可以部署到网络

```html
# 本地测试（需要Python）
python3 -m http.server 8000

# GitHub Pages 部署
# 1. 创建新仓库
# 2. 上传HTML文件到仓库
# 3. 在Settings > Pages中启用
```
## 自定义配置
如需修改任务内容，只需编辑代码中的 tasks 数组：

```html
const tasks = [
  "准备会前播放视频。",
  "按照中心统一格式模版制作、打印会议议程（参会领导、参会人员、工作人员每人1份）、签到表（1份），发放到位。",
  // ...其他任务
];
```
如需调整样式，可在< style >部分修改相应CSS规则。
## 二维码库 CDN 的获取
- 正确库：[qrcode.js by davidshimjs](https://github.com/davidshimjs/qrcodejs)
- CDN 获取方式（推荐使用 cdnjs）
打开：[https://cdnjs.com/libraries/qrcodejs](https://cdnjs.com/libraries/qrcodejs)
找到最新版本（如 1.0.0）
复制引入代码：

```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
```
特点：
- 免费、稳定、全球加速
- 支持 new QRCode(element, options)
- 无需 Node.js，纯前端使用

## 如何让手机真正访问
⚠️ 注意：如果你是双击打开 HTML 文件（路径是 file:///...），手机无法访问，因为不是网络地址。

解决方案：本地启动一个服务器
方法 1：使用 VS Code + Live Server
安装 VS Code
安装插件：Live Server
右键 HTML 文件 → “Open with Live Server”
浏览器打开：http://127.0.0.1:5500/your-file.html
手机和电脑在同一 Wi-Fi 下，手机浏览器访问你的 电脑局域网 IP，如：http://192.168.1.100:5500/your-file.html
**局域网 IP 查看方式：** 

Windows：ipconfig → 找 IPv4 地址
Mac：系统设置 → 网络 → 查看 IP
方法 2：使用 Python 快速启动

```bash
# 在文件所在目录运行
python -m http.server 8000
```
然后访问：http://localhost:8000 或 http://你的IP:8000


# 🙏 鸣谢
- [davidshimjs/qrcodejs](https://github.com/davidshimjs/qrcodejs) - 优秀的二维码生成库
- [eKoopmans/html2pdf.js](https://github.com/eKoopmans/html2pdf.js) - 强大的HTML转PDF工具
- 所有贡献者和用户 - 让这个工具变得更好
